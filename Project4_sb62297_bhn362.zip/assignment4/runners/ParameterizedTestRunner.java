package assignment4.runners;

public class ParameterizedTestRunner extends TestRunner {

    public ParameterizedTestRunner(Class testClass) {
        super(testClass);
    }
}
