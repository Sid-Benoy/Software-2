package assignment4.runners;

public class OrderedTestRunner extends TestRunner {

    public OrderedTestRunner(Class testClass) {
        super(testClass);
    }
}
