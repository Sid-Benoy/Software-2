package assignment2;

public class Word {
    String words[];
    public Word(String[] words){
            for(int i = 0; i < words.length; i++) {
                if(words[i]!=null)
                    System.out.println(words[i]);
            }
            System.out.println("--------");
    }







}
